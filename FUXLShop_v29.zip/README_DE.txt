FUXLShop v28
- Chat mit interner stabiler Geräte-ID (UUID), für Nutzer verborgen
- Benutzername (@name) und Anzeigename
- Telefonnummer optional und privat, nicht im Chat/QR/Profil übertragen
- Kontakte über QR oder Teilen hinzufügen
- Audio-/Videoanrufe bleiben erhalten
- Scanner, Generator, Übersetzen, Social und Verlauf aus v27 bleiben enthalten
Hinweis: Ohne eigenen Server ist der Benutzername nicht global durchsuchbar. QR/Teilen überträgt die interne technische ID verborgen, damit die direkte Peer-Verbindung funktioniert.
