const CACHE='fuxlshop-v19';
const SHELL=['./','./index.html','./manifest.webmanifest'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.origin!==location.origin) return;
  // Für die Seite selbst: immer zuerst versuchen, das Neueste online zu holen (Network-First).
  if(e.request.mode==='navigate' || u.pathname.endsWith('/index.html') || u.pathname==='/' ){
    e.respondWith(
      fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r;})
      .catch(()=>caches.match(e.request).then(cached=>cached||caches.match('./index.html')))
    );
    return;
  }
  // Für alles andere (Icons etc.): Cache-First mit Nachladen im Hintergrund.
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match('./index.html'))));
});
